def sumar(op1, op2):
    print("la suma es : ", op1+op2)

def restar(op1, op2):
    print("la resta es : ", op1-op2)

def multiplicar(op1, op2):
    print("la  multiplicacion es : ", op1*op2)

def dividir(op1,op2):

    print("la division es : ", op1/op2)

def potencia(base,exponente):

    print("El resultado es : ", base**exponente)

def redondear(numero):
    print("El resultado es :", round(numero))

    